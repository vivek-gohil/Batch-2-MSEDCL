CREATE DATABASE employee_db;

USE employee_db;

CREATE TABLE employee (
    emp_id BIGINT PRIMARY KEY,
    emp_name VARCHAR(100),
    department VARCHAR(50),
    salary DECIMAL(10,2)
);

INSERT INTO employee VALUES
(101,'John','IT',50000);

INSERT INTO employee VALUES
(102,'David','HR',60000);

INSERT INTO employee VALUES
(103,'Smith','Finance',70000);

-- Procedure 1 - Get Employee By ID
DELIMITER $$

CREATE PROCEDURE get_employee(
    IN p_emp_id BIGINT
)
BEGIN
    SELECT *
    FROM employee
    WHERE emp_id = p_emp_id;
END $$

DELIMITER ;

-- Procedure 2 - Get All Employees

DELIMITER $$

CREATE PROCEDURE get_all_employees()
BEGIN
    SELECT *
    FROM employee;
END $$

DELIMITER ; 

-- Procedure 3 - Calculate Bonus
DELIMITER $$

CREATE PROCEDURE calculate_bonus(
    IN p_emp_id BIGINT,
    OUT p_bonus DECIMAL(10,2)
)
BEGIN

    SELECT salary * 0.10
    INTO p_bonus
    FROM employee
    WHERE emp_id = p_emp_id;

END $$

DELIMITER ;

-- Procedure 4 - Update Salary
DELIMITER $$

CREATE PROCEDURE update_salary(
    IN p_emp_id BIGINT,
    IN p_increment DECIMAL(10,2)
)
BEGIN

    UPDATE employee
    SET salary = salary + p_increment
    WHERE emp_id = p_emp_id;

END $$

DELIMITER ;

-- Procedure 5 - Employee Count
DELIMITER $$

CREATE PROCEDURE get_employee_count(
    OUT total_count INT
)
BEGIN

    SELECT COUNT(*)
    INTO total_count
    FROM employee;

END $$

DELIMITER ;