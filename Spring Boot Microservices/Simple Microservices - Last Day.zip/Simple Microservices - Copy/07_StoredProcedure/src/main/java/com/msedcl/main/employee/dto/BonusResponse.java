package com.msedcl.main.employee.dto;

public class BonusResponse {

	private Double bonus;

	public BonusResponse(Double bonus) {
		this.bonus = bonus;
	}

	public Double getBonus() {
		return bonus;
	}

	public void setBonus(Double bonus) {
		this.bonus = bonus;
	}
}
