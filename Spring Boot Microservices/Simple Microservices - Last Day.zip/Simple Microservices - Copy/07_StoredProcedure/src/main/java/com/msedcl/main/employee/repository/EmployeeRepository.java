package com.msedcl.main.employee.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;

import com.msedcl.main.employee.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

	@Query(value = "CALL get_employee(:id)", nativeQuery = true)
	List<Employee> getEmployee(Long id);

	@Query(value = "CALL get_all_employees()", nativeQuery = true)
	List<Employee> getAllEmployees();

	@Procedure(procedureName = "get_employee_count")
	Integer getEmployeeCount();
}
