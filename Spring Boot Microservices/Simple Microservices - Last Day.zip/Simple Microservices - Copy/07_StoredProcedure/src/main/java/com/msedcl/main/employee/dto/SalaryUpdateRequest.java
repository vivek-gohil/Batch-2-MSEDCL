package com.msedcl.main.employee.dto;

import lombok.Data;

@Data
public class SalaryUpdateRequest {

	private Long empId;
	private Double increment;

}
