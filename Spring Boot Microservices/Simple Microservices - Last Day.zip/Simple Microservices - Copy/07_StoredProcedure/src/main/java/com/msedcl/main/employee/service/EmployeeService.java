package com.msedcl.main.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.msedcl.main.employee.dto.BonusResponse;
import com.msedcl.main.employee.dto.SalaryUpdateRequest;
import com.msedcl.main.employee.entity.Employee;
import com.msedcl.main.employee.repository.EmployeeRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.StoredProcedureQuery;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository repository;

	@PersistenceContext
	private EntityManager entityManager;

	public List<Employee> getAllEmployees() {
		return repository.getAllEmployees();
	}

	public Employee getEmployee(Long id) {
		return repository.getEmployee(id).get(0);
	}

	public Integer getEmployeeCount() {
		return repository.getEmployeeCount();
	}

	public BonusResponse calculateBonus(Long empId) {

		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("calculate_bonus");
		query.registerStoredProcedureParameter("p_emp_id", Long.class, ParameterMode.IN);
		query.registerStoredProcedureParameter("p_bonus", Double.class, ParameterMode.OUT);
		query.setParameter("p_emp_id", empId);
		query.execute();

		Double bonus = (Double) query.getOutputParameterValue("p_bonus");

		return new BonusResponse(bonus);
	}

	public String updateSalary(SalaryUpdateRequest request) {

		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("update_salary");
		query.registerStoredProcedureParameter("p_emp_id", Long.class, ParameterMode.IN);
		query.registerStoredProcedureParameter("p_increment", Double.class, ParameterMode.IN);
		query.setParameter("p_emp_id", request.getEmpId());
		query.setParameter("p_increment", request.getIncrement());
		query.execute();

		return "Salary Updated Successfully";
	}
}
