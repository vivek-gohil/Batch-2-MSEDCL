package com.msedcl.main.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.msedcl.main.employee.dto.BonusResponse;
import com.msedcl.main.employee.dto.SalaryUpdateRequest;
import com.msedcl.main.employee.entity.Employee;
import com.msedcl.main.employee.service.EmployeeService;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	@GetMapping
	public List<Employee> getAllEmployees() {
		return service.getAllEmployees();
	}

	@GetMapping("/{id}")
	public Employee getEmployee(@PathVariable Long id) {

		return service.getEmployee(id);
	}

	@GetMapping("/count")
	public Integer getCount() {
		return service.getEmployeeCount();
	}

	@GetMapping("/bonus/{id}")
	public BonusResponse getBonus(@PathVariable Long id) {

		return service.calculateBonus(id);
	}

	@PostMapping("/salary")
	public String updateSalary(@RequestBody SalaryUpdateRequest request) {

		return service.updateSalary(request);
	}
}