package com.msedcl.main.employee.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.msedcl.main.employee.entity.Employee;
import com.msedcl.main.employee.service.EmployeeService;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

	private final EmployeeService service;

	public EmployeeController(EmployeeService service) {
		this.service = service;
	}

	@GetMapping("/{id}")
	public Employee getEmployee(@PathVariable Long id) {

		return service.getEmployee(id);
	}

	@PutMapping
	public Employee updateEmployee(@RequestBody Employee employee) {

		return service.updateEmployee(employee);
	}

	@DeleteMapping("/{id}")
	public String deleteEmployee(@PathVariable Long id) {

		service.deleteEmployee(id);

		return "Deleted Successfully";
	}
}
