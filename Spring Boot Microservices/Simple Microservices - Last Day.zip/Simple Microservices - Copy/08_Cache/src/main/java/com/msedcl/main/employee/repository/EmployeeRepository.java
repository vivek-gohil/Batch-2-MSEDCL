package com.msedcl.main.employee.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.msedcl.main.employee.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

}
