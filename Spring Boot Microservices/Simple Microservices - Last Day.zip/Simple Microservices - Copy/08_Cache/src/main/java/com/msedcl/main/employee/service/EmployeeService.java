package com.msedcl.main.employee.service;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.msedcl.main.employee.entity.Employee;
import com.msedcl.main.employee.repository.EmployeeRepository;

@Service
public class EmployeeService {

	private final EmployeeRepository repository;

	public EmployeeService(EmployeeRepository repository) {
		this.repository = repository;
	}

	@Cacheable(value = "employees", key = "#id")
	public Employee getEmployee(Long id) {

		System.out.println("Fetching employee from DB");

		return repository.findById(id).orElseThrow(() -> new RuntimeException("Employee Not Found"));
	}

	@CachePut(value = "employees", key = "#employee.id")
	public Employee updateEmployee(Employee employee) {

		System.out.println("Updating DB");

		return repository.save(employee);
	}

	@CacheEvict(value = "employees", key = "#id")
	public void deleteEmployee(Long id) {

		repository.deleteById(id);
	}
}
