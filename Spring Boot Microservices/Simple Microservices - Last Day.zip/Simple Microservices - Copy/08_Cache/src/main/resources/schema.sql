CREATE DATABASE employee_db;

USE employee_db;

CREATE TABLE employee(
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    department VARCHAR(100),
    salary DOUBLE
);

INSERT INTO employee(name,department,salary)
VALUES
('John','IT',50000),
('Mike','HR',40000),
('David','Finance',60000);

SELECT * FROM employee;